<?php
    $con=mysqli_connect("localhost","root","","students-management")or die(mysqli_error($con))
    ?>