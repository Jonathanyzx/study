 <?php
session_start();
error_reporting();
if (!isset($_SESSION['username'])) {
	header("location:index.php");
}
else{
?>
<?php
include 'connect.php';
if(isset($_POST['submit'])){
	  $id=$_POST['id'];
      $ln = $_POST['Names'];
      $age = $_POST['Age'];
      $gender = $_POST['Gender'];
      $marks = $_POST['Marks'];
$add=mysqli_query($con,"INSERT INTO students (Names,Age,gender,Marks)VALUES('$ln','$age','$gender','$marks')");
    if($add){
    	header("location:students.php");
    }
    else{
        echo "Failed to insert";
    }
}
?>


<div class="hd">
    <h2>STUDENTS</h2>
</div><br/><br/><br/><br/>
<center>
	<fieldset style="border: 2px solid black;border-radius: 5px;margin-right: 50px;">
		<form action="register.php" method="POST">
              

    
  
    <p>NAMES:</p>
    <input type="text" name="Names"  placeholder="Enter Last Name" required>

    <p>AGE:</p>
    <input type="number" name="Age"  placeholder="Enter Age" required>
    
    <p>GENDER:</p>
    <select name="Gender" required>
        <option value="">Select Gender</option>
        <option value="m">Male</option>
        <option value="f" >Female</option>
    </select>
    
    <p>MARKS:</p>
    <input type="number" name="Marks"  placeholder="Enter Marks" required>
    
    <p>
        <input type="submit" name="submit" value="Register Student  ">
        <input type="reset" name="reset" value="Cancel">
    </p>
</form>
        </fieldset>
		<a href="logout.php" class="logout-btn">Logout</a>
    </center>
	<?php
}

?>
